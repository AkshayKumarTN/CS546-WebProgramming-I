/*Here, you can export the data functions
to get the stocks, people, getStockById, getPersonById.  You will import these functions into your routing files and call the relevant function depending on the route. 
*/

const getStocks = async () => {};

const getPeople = async () => {};

const getStockById = async (id) => {};

const getPersonById = async (id) => {};
