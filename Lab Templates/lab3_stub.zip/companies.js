//Export the following functions using ES6 Syntax
const listEmployees = async (companyName) => {};

const sameIndustry = async (industry) => {};

const getCompanyById = async (id) => {};
