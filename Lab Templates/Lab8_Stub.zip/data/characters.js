//import axios, md5

export const searchCharactersByName = async (name) => {
  //Function to search the api and return up to 15 characters matching the name param
};

export const getCharacterById = async (id) => {
  //Function to fetch a character from the api matching the id
};
