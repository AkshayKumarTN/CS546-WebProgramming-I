/* Todo: Implment the functions below and then export them
      using ES6 syntax. 
      DO NOT CHANGE THE FUNCTION NAMES
*/

let arrayStats = (array) => {};

let mergeCommonElements = (...arrays) => {
  //this function takes in a variable number of arrays that's what the ...arrays signifies
};

let numberOfOccurrences = (...arrays) => {
  //this function takes in a variable number of arrays that's what the ...arrays signifies
};
