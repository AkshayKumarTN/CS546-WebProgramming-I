/* Todo: Implment the functions below and then export them
      using ES6 syntax. 
      DO NOT CHANGE THE FUNCTION NAMES
*/

let camelCase = (str) => {};

let replaceCharsAtIndexes = (str, idxArr) => {};

let compressString = (str) => {};
