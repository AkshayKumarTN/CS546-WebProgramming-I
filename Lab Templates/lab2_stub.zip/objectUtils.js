/* Todo: Implment the functions below and then export them
      using ES6 syntax. 
      DO NOT CHANGE THE FUNCTION NAMES
*/

let deepEquality = (obj1, obj2) => {};

let commonKeysValues = (obj1, obj2) => {};

let calculateObject = (object, func) => {};
