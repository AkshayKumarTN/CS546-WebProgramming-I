//import mongo collections, bcrypt and implement the following data functions
export const register = async (
  firstName,
  lastName,
  userId,
  password,
  favoriteQuote,
  themePreference,
  role
) => {};

export const login = async (userId, password) => {};
