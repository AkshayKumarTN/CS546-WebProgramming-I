//export the following functions using ES6 syntax
const createMovie = async (
  title,
  plot,
  genres,
  rating,
  studio,
  director,
  castMembers,
  dateReleased,
  runtime
) => {};

const getAllMovies = async () => {};

const getMovieById = async (id) => {};

const removeMovie = async (id) => {};

const renameMovie = async (id, newName) => {};
