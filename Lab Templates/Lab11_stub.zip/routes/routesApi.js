// Set-Up Routes

router
  .route('/')
  .get(async (req, res) => {
    //code here for GET to show static HTML flie
  })
